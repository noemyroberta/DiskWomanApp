package br.ifal.app.womancomplaintuser.daos;

import java.util.ArrayList;
import java.util.List;

import br.ifal.app.womancomplaintuser.beans.Addresses;

public class AddressesDAO {

    public static List<Addresses> listAddresses = new ArrayList<>();
}
