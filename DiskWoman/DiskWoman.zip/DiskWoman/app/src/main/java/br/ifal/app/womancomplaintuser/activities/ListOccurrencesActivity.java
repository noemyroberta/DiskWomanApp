package br.ifal.app.womancomplaintuser.activities;

import android.support.v7.app.AppCompatActivity;

public class ListOccurrencesActivity extends AppCompatActivity {


}
