package br.ifal.app.womancomplaintuser.daos;

import java.util.ArrayList;
import java.util.List;

import br.ifal.app.womancomplaintuser.beans.Womans;

public class WomansDAO {

    public static List<Womans> listWomans = new ArrayList<>();

}
