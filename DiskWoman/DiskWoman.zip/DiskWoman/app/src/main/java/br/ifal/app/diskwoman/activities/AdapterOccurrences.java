package br.ifal.app.diskwoman.activities;

public class AdapterOccurrences {
}
