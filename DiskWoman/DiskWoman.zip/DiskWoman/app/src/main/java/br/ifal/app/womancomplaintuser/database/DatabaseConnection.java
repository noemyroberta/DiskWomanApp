package br.ifal.app.womancomplaintuser.database;

import android.database.sqlite.SQLiteDatabase;

public class DatabaseConnection extends SQLiteDatabase {


}
