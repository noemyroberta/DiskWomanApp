package br.ifal.app.diskwoman.activities;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

}
